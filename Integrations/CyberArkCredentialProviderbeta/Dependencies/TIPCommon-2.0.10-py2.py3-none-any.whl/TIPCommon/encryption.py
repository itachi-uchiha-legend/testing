from __future__ import annotations

import base64

from Crypto import Random
from Crypto.Cipher import AES
from Crypto.Protocol.KDF import PBKDF2


BLOCK_SIZE: int = 16


def get_private_key(password: str) -> bytes:
    """Derive a key from a password.

    Args:
        password: The password to generate the key from

    Returns:
        A byte string
    """
    salt: bytes = b"this is a salt"
    kdf: bytes = PBKDF2(password, salt, dkLen=BLOCK_SIZE * 4)
    key: bytes = kdf[:32]
    return key


def encrypt(data: str, key: str) -> bytes:
    """Encrypt data with the key
    Args:
        data: json string to encrypt
        key: password to use for key generation

    Returns:
        The encrypted message
    """
    private_key: bytes = get_private_key(key)
    iv: bytes = Random.new().read(AES.block_size)
    raw: str = _pad(data)
    aes: AES = AES.new(private_key, AES.MODE_GCM, iv)
    encrypted: bytes = aes.encrypt(raw.encode())
    return base64.b64encode(iv + encrypted)


def decrypt(enc_data: bytes, key: str) -> str:
    """Decrypt data with the password

    Args:
        enc_data: data to encrypt
        key: password to use for key generation

    Returns:
        The decrypted message
    """
    private_key: bytes = get_private_key(key)
    enc_data: bytes = base64.b64decode(enc_data)
    iv: bytes = enc_data[:16]
    cipher: AES = AES.new(private_key, AES.MODE_GCM, iv)
    return _unpad(cipher.decrypt(enc_data[16:])).decode()


def _pad(s: str) -> str:
    """Adjust str length to the multiple of BLOCK_SIZE

    Args:
        s: A string to adjust

    Returns:
        The padded string
    """
    adjusted_block_size: int = BLOCK_SIZE - len(s) % BLOCK_SIZE
    return s + adjusted_block_size * chr(adjusted_block_size)


def _unpad(b: bytes) -> bytes:
    """Adjust bytes length to the multiple of BLOCK_SIZE

    Args:
        b: A bytes object to adjust

    Returns:
        The string unpadded
    """
    return b[: -ord(b[len(b) - 1:])]
