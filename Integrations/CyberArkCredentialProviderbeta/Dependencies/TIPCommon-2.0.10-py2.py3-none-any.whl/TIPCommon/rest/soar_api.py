from __future__ import annotations

import json

from requests import HTTPError, Response

from ..data_models import (
    AlertEvent,
    CaseDetails,
    CaseWallAttachment,
    ConnectorCard,
    CustomField,
    CustomFieldValue,
    InstalledIntegrationInstance,
)
from ..exceptions import InternalJSONDecoderError
from ..types import ChronicleSOAR, SingleJson
from ..utils import is_python_37, none_to_default_value


if is_python_37():
    from urllib.parse import urljoin
else:
    from urlparse import urljoin


class SoarApiServerError(Exception):
    """Errors from Chronicle SOAR's API calls to the server"""


def validate_response(response, validate_json=False):
    # type: (Response, bool) -> None
    """Validate response and get it as a JSON

    Args:
        response (requests.Response): The response to validate

    Raises:
        HTTPError: If the response status code is pointing on some failure
        InternalJSONDecoderError: If the response failed to be parsed as JSON
    """
    try:
        response.raise_for_status()

        if validate_json:
            response.json()

    except HTTPError as he:
        raise HTTPError('An error happened while requesting API, {}'.format(he))

    except json.JSONDecodeError as je:
        raise InternalJSONDecoderError(
            'Failed to parse response as JSON.\nError: {0}\nRaw response: {1}'
            .format(je, response.text)
        )


# ==== GET ==== #
def get_case_overview_details(chronicle_soar, case_id):
    # type: (ChronicleSOAR, int | str) -> CaseDetails
    """Get case overview details by case ID

    Args:
        chronicle_soar (ChronicleSOAR): A chronicle soar SDK object
        case_id (int | str) The case id to fetch its overview data

    Returns:
        (CaseDetails): The case details object

    Raises:
        requests.HTTPError: If failed to request or request status is not 200
        json.JSONDecoderError: If parsing the response fails
    """
    endpoint = 'api/external/v1/dynamic-cases/GetCaseDetails/{}'.format(case_id)
    url = urljoin(chronicle_soar.API_ROOT, endpoint)

    chronicle_soar.LOGGER.info(
        'Calling endpoint {} to get case overview details'.format(endpoint)
    )

    response = chronicle_soar.session.get(url=url)
    validate_response(response, validate_json=True)

    return CaseDetails.from_json(response.json())


def get_installed_jobs(chronicle_soar):
    # type: (ChronicleSOAR) -> list[SingleJson]
    """Retrieve a list of environment action definition files.

    Args:
        chronicle_soar (ChronicleSOAR): A chronicle soar SDK object

    Returns:
        (list[SingleJson]): A list of `SingleJson` objects representing
        the action definition files.

    Raises:
        requests.HTTPError:
        json.JSONDecodeError:
    """
    endpoint = 'api/external/v1/jobs/GetInstalledJobs'
    url = urljoin(chronicle_soar.API_ROOT, endpoint)

    chronicle_soar.LOGGER.info(
        f'Calling endpoint "{endpoint}" to get all job installed instances'
    )
    response = chronicle_soar.session.get(url)
    validate_response(response, validate_json=True)

    return response.json()


def get_connector_cards(chronicle_soar):
    # type: (ChronicleSOAR) -> list[ConnectorCard]
    """Gets all the connector cards.

    Args:
        chronicle_soar (ChronicleSOAR): A chronicle soar SDK object.

    Returns:
        list[str]: list of all connector cards.
    """
    connector_cards = []
    endpoint = 'api/external/v1/connectors/cards?format=camel'
    address = urljoin(chronicle_soar.API_ROOT, endpoint)

    chronicle_soar.LOGGER.info(
        'Calling endpoint "{0}" to get all connector instances.'.format(endpoint)
    )
    response = chronicle_soar.session.get(address)
    validate_response(response, validate_json=True)
    for connector_card in response.json():
        integration = connector_card.get('integration')
        cards = connector_card.get('cards')
        cards = [
            ConnectorCard.from_json(
                connector_card_json={**card, 'integration': integration}
            )
            for card in cards
        ]
        connector_cards.extend(cards)

    return connector_cards


def list_custom_fields(
        chronicle_soar,
        filter_: str | None = None,
) -> list[CustomField]:
    """List custom fields.

    Args:
        chronicle_soar: A chronicle soar SDK object
        filter_: Filter value for the search

    Returns:
        (list[CustomField]): The case details object

    Raises:
        requests.HTTPError: If failed to request or request status is not 200
        json.JSONDecoderError: If parsing the response fails
    """
    endpoint = 'api/1p/external/v1/customFields'
    params = {}
    if filter_ is not None:
        params['$filter'] = filter_

    url = urljoin(chronicle_soar.API_ROOT, endpoint)
    response = chronicle_soar.session.get(url=url, params=params)
    validate_response(response, validate_json=True)

    return [
        CustomField.from_json(item) for item in response.json()['items']
    ]


def list_custom_field_values(
        chronicle_soar,
        parent: str,
) -> list[CustomFieldValue]:
    """Get custom field value for case or alert.

    Args:
        chronicle_soar: A chronicle soar SDK object
        parent: Parent path for custom field value, f. ex.: cases/1, cases/1/alerts/1

    Returns:
        (list[CustomFieldValue]): The case details object

    Raises:
        requests.HTTPError: If failed to request or request status is not 200
        json.JSONDecoderError: If parsing the response fails
    """
    endpoint = f'api/1p/external/v1/{parent}/customFieldValues'
    url = urljoin(chronicle_soar.API_ROOT, endpoint)
    response = chronicle_soar.session.get(url=url)
    validate_response(response, validate_json=True)

    return [
        CustomFieldValue.from_json(item) for item in response.json()['items']
    ]


def set_custom_field_values(
    chronicle_soar, parent: str, custom_field_id: int, values: [str]
) -> CustomFieldValue:
    """
    Set custom field values

    Args:
        chronicle_soar: A chronicle soar SDK object
        parent (str): parent path for custom field value i.e.: cases/1, cases/1/alerts/1
        custom_field_id (int): custom field id
        values ([str]): list of custom field values to set

    Returns:
        CustomFieldValue: CustomFieldValue object
    """
    endpoint = f'api/1p/external/v1/{parent}/customFieldValues/{custom_field_id}'
    url = urljoin(chronicle_soar.API_ROOT, endpoint)
    payload = {
        'values': values
    }
    response = chronicle_soar.session.patch(url=url, json=payload)
    validate_response(response, validate_json=True)
    return CustomFieldValue.from_json(response.json())


def batch_set_custom_field_values(
    chronicle_soar,
    identifier: int,
    parent: str,
    custom_fields_values_mapping: dict[int: list[str]]
) -> list[CustomFieldValue]:
    """
    Batch set custom fields values

    Args:
        chronicle_soar: A chronicle soar SDK object
        identifier (int): parent identifier
        parent (str): parent path for custom field value i.e.: cases/1, cases/1/alerts/1
        custom_fields_values_mapping (dict[int: list[str]]): custom field ids to
            values mapping

    Returns:
        list[CustomFieldValue]: list of CustomFieldValue objects
    """
    endpoint = f'api/1p/external/v1.0/{parent}/customFieldValues:batchUpdate'
    url = urljoin(chronicle_soar.API_ROOT, endpoint)
    requests = []

    for custom_field_id, custom_field_values in custom_fields_values_mapping.items():
        requests.append({
            'customFieldId': custom_field_id,
            'values': custom_field_values,
            'identifier': identifier
        })

    payload = {'requests': requests}
    response = chronicle_soar.session.post(url=url, json=payload)
    validate_response(response, validate_json=True)

    return [
        CustomFieldValue.from_json(custom_field_value)
        for custom_field_value in response.json().get('customFieldValues', [])
    ]


# ==== POST ==== #
def get_user_profile_cards(
        chronicle_soar,
        search_term='',
        requested_page=0,
        page_size=20,
        filter_by_role=False,
        filter_disabled_users=False,
        filter_support_users=False,
        fetch_only_support_users=False,
        filter_permission_types=None,
):
    # type: (ChronicleSOAR, str, int, int, bool, bool, bool, bool, list[int] | None) -> SingleJson
    """Retrieve user profile cards by page and filter.

    Args:
        chronicle_soar (ChronicleSOAR): A chronicle soar SDK object
        search_term (str): Search terms
        requested_page (int): Starting offset for returning a users' page
        page_size (int): Number of users to return
        filter_by_role (bool): Whether to filter out by role
        filter_disabled_users (bool): Whether to filter out disabled users
        filter_support_users (bool): Whether to filter out support users
        fetch_only_support_users (bool): Whether to return support users only.
        filter_permission_types (list[int] | None):
            List of filter permission types (e.g. 0)

    Examples:
        An example of the response JSON:
        {
            "objectsList": [
                {
                "firstName": "string",
                "lastName": "string",
                "userName": "string",
                "accountState": 0
                }
            ],
            "metadata": {
                "totalNumberOfPages": 0,
                "totalRecordsCount": 0,
                "pageSize": 0
            }
        }

    Returns:
        SingleJson: The response from SOAR server - the user profile card

    Raises:
        requests.HTTPError: If server returns a non-success status code
        json.JSONDecodeError: If the returned value is not a valid JSON
    """
    filter_permission_types = none_to_default_value(filter_permission_types, [])

    endpoint = 'api/external/v1/settings/GetUserProfileCards'
    url = urljoin(chronicle_soar.API_ROOT, endpoint)
    payload = {
        "searchTerm": search_term,
        "requestedPage": requested_page,
        "pageSize": page_size,
        "filterRole": filter_by_role,
        "filterDisabledUsers": filter_disabled_users,
        "filterSupportUsers": filter_support_users,
        "fetchOnlySupportUsers": fetch_only_support_users,
        "filterPermissionTypes": filter_permission_types,
    }

    chronicle_soar.LOGGER.info(
        'Calling endpoint {} to user profile cards'.format(endpoint)
    )
    response = chronicle_soar.session.post(url, json=payload)
    validate_response(response)

    return response.json()


def get_alert_events(chronicle_soar, case_id, alert_identifier):
    # type: (ChronicleSOAR, str | int, str) -> list[AlertEvent]
    """Get specific alert's events

    Args:
        chronicle_soar (ChronicleSOAR): _description_
        case_id (str | int): Case ID. Example: 13, "41"
        alert_identifier (str):
            The alert's identifier (='{alert.name}_{alert.id}'). Example:
            alert.name=SERVICE_ACCOUNT_USED
            alert.id=c3b80f09-38d3-4328-bddb-b938ccee0256
            identifier=SERVICE_ACCOUNT_USED_c3b80f09-38d3-4328-bddb-b938ccee0256

    Returns:
        list[SingleJson]: The request's response JSON. A list of events' JSONs

    Raises:
        requests.HTTPError: If server returns a non-success status code
        json.JSONDecodeError: If the returned value is not a valid JSON
    """
    endpoint = 'api/external/v1/dynamic-cases/GetAlertEvents'
    url = urljoin(chronicle_soar.API_ROOT, endpoint)
    payload = {
        'caseId': case_id,
        'alertIdentifier': alert_identifier,
    }

    chronicle_soar.LOGGER.info(
        'Calling endpoint {} to user profile cards'.format(endpoint)
    )
    response = chronicle_soar.session.post(url, json=payload)
    validate_response(response)

    return [AlertEvent.from_json(event) for event in response.json()]


def get_env_action_def_files(chronicle_soar):
    # type: (ChronicleSOAR) -> list[SingleJson]
    """Retrieve a list of environment action definition files.

    Args:
        chronicle_soar (ChronicleSOAR): A chronicle soar SDK object

    Returns:
        (list[SingleJson]): A list of `SingleJson` objects representing
        the action definition files.

    Raises:
        requests.HTTPError:
        json.JSONDecodeError:
    """
    endpoint = 'external/v1/settings/GetEnvironmentActionDefinitions'
    url = urljoin(chronicle_soar.API_ROOT, endpoint)
    payload = [chronicle_soar.environment]

    chronicle_soar.LOGGER.info(
        'Calling endpoint {} to get all actions def files'.format(endpoint)
    )
    response = chronicle_soar.session.post(url, json=payload)
    validate_response(response, validate_json=True)

    return response.json()


def get_integration_full_details(chronicle_soar, integration_identifier):
    # type: (ChronicleSOAR, str) -> SingleJson
    """Retrieves the full-details file of the integration.

    Args:
        chronicle_soar (ChronicleSOAR): A chronicle soar SDK object
        integration_identifier (str): The integration's ID (e.g. VirusTotalV3)


    Returns:
        (SingleJSON): The response JSON containing the full details of the integration.

    Raises:
        requests.HTTPError:
        json.JSONDecodeError:
    """
    # FIXME: Might not work on custom integrations
    endpoint = 'external/v1/store/GetIntegrationFullDetails'
    url = urljoin(chronicle_soar.API_ROOT, endpoint)
    payload = {
        "integrationIdentifier": integration_identifier
    }

    chronicle_soar.LOGGER.info(
        'Calling endpoint {} to get the integration '.format(endpoint) +
        'configuration parameters'
    )
    response = chronicle_soar.session.post(url, json=payload)
    validate_response(response, validate_json=True)

    return response.json()


def get_installed_integrations_of_environment(chronicle_soar, environment):
    # type: (ChronicleSOAR, str) -> list[InstalledIntegrationInstance]
    """Fetch all integrations installed for provided environments.

    Args:
        chronicle_soar (ChronicleSOAR): A chronicle soar SDK object.
        environment (str): instance environments list.

    Returns:
        A list of dictionary objects representing integration instances.
    """

    endpoint = 'api/external/v1/integrations/GetEnvironmentInstalledIntegrations'
    address = urljoin(chronicle_soar.API_ROOT, endpoint)
    payload = {'name': '*' if environment == 'Shared Instances' else environment}

    chronicle_soar.LOGGER.info(
        'Calling endpoint "{0}" to get all installed '.format(endpoint) +
        'integration instances.'
    )
    response = chronicle_soar.session.post(address, json=payload)
    validate_response(response, validate_json=True)

    return [
        InstalledIntegrationInstance.from_json(instance)
        for instance in response.json()['instances']
    ]


def set_alert_priority(chronicle_soar, case_id, alert_identifier, alert_name, priority):
    # type: (ChronicleSOAR, int, str, str, str) -> None
    """Set alert priority.

    Args:
        chronicle_soar (ChronicleSoar): A chronicle soar SDK object
        case_id (int): Chronicle SOAR case ID
        alert_identifier (str): Chronicle SOAR Alert Identifier
        alert_name (str): Chronicle SOAR Alert Name
        priority (int): Chronicle SOAR priority enum value

    Raises:
        requests.HTTPError:
    """
    request_dict = {
        'caseId': case_id,
        'alertIdentifier': alert_identifier,
        'alertName': alert_name,
        'priority': priority
    }
    endpoint = 'api/external/v1/sdk/UpdateAlertPriority'
    url = urljoin(chronicle_soar.API_ROOT, endpoint)
    response = chronicle_soar.session.post(url, json=request_dict)
    validate_response(response, validate_json=False)


def remove_case_tag(chronicle_soar, case_id, tag, alert_identifier=None):
    # type: (ChronicleSOAR, int, str, str) -> None
    """Remove a case tag.

    Args:
        chronicle_soar (ChronicleSoar): A chronicle soar SDK object
        case_id (int): Chronicle SOAR case ID
        alert_identifier (str): Chronicle SOAR Alert Identifier
        tag (str): A tag to remove

    Raises:
        requests.HTTPError:
    """
    request_dict = {
        'caseId': case_id,
        'alertIdentifier': alert_identifier,
        'tag': tag
    }
    endpoint = 'api/external/v1/cases/RemoveCaseTag'
    url = urljoin(chronicle_soar.API_ROOT, endpoint)
    response = chronicle_soar.session.post(url, json=request_dict)
    validate_response(response, validate_json=False)


def get_entity_data(
        chronicle_soar,
        entity_identifier,
        entity_environment,
        entity_type=None,
        last_case_type=0,
        case_distribution_type=0
):
    # type: (ChronicleSOAR, str, str, str | None, int, int) -> SingleJson
    """Fetch entity data.

    Args:
        chronicle_soar (ChronicleSoar): A chronicle soar SDK object
        entity_identifier (int): Entity identifier
        entity_environment (str): Entity environment
        entity_type (str): Entity type
        last_case_type: (int): Last case type
        case_distribution_type: (int): Case distribution type

    Raises:
        requests.HTTPError:

    Returns:
        dict: Entity
    """
    request_dict = {
        'entityIdentifier': entity_identifier,
        'entityType': entity_type,
        'entityEnvironment': entity_environment,
        'lastCaseType': last_case_type,
        'caseDistributionType': case_distribution_type
    }
    endpoint = '/api/external/v1/entities/GetEntityData'
    url = urljoin(chronicle_soar.API_ROOT, endpoint)
    response = chronicle_soar.session.post(url, json=request_dict)
    validate_response(response, validate_json=False)
    return response.json()


# ==== PATCH ==== #
def set_case_score_bulk(
        chronicle_soar: ChronicleSOAR,
        case_score_mapping: list[dict[str, int | float]]
) -> SingleJson:
    """Set case scores in bulk.

    Args:
        chronicle_soar (ChronicleSoar): A chronicle soar SDK object
        case_score_mapping (int): Chronicle SOAR case ID to Score mapping.

    Examples:
        case_score_mapping = [
            {
                "caseId": 1,
                "score": 1.0
            }
        ]

    Raises:
        requests.HTTPError:

    Returns:
        Response JSON, contains success status and lists of failed cases if any.
        {
            "isSuccessful": false,
            "invalidScoreCaseIds": [2],
            "notFoundCaseIds": null
        }
    """
    request_dict = {
        "caseScores": case_score_mapping
    }
    endpoint = 'api/external/v1/sdk/cases/score'
    url = urljoin(chronicle_soar.API_ROOT, endpoint)
    response = chronicle_soar.session.patch(url, json=request_dict)
    validate_response(response, validate_json=False)
    return response.json()


def save_attachment_to_case_wall(
    chronicle_soar: ChronicleSOAR,
    attachment_data: CaseWallAttachment,
) -> None:
    """Save file directly to the case wall.

    Args:
        chronicle_soar (ChronicleSoar): A chronicle soar SDK object
        attachment_data (CaseWallAttachment): ..data_models.CaseWallAttachment object.
        verify_ssl (bool, optional): Verify SSL flag for api request. Defaults to True.
    """
    file_name = f'{attachment_data.name}{attachment_data.file_type}'
    request_dict = {
        'CaseIdentifier': chronicle_soar.case_id,
        'Base64Blob': attachment_data.base64_blob,
        'Name': attachment_data.name,
        'Description': f'File "{file_name}" added to the case wall.',
        'Type': attachment_data.file_type,
        'IsImportant': attachment_data.is_important,
    }
    endpoint = 'api/external/v1/cases/AddEvidence/'
    url = urljoin(chronicle_soar.API_ROOT, endpoint)
    response = chronicle_soar.session.post(url=url, json=request_dict)

    validate_response(response=response)
