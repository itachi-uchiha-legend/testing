import abc
from typing import Generic, TypeVar

from .session import AuthenticatedSession
from ...types import ApiParams


class Apiable(abc.ABC, Generic[ApiParams]):
    """Interface for classes that manage API calls to external services."""

    @abc.abstractmethod
    def __init__(
        self,
        authenticated_session: AuthenticatedSession,
        configuration: ApiParams,
    ) -> None:
        self.session: AuthenticatedSession = authenticated_session
        self.configuration: ApiParams = configuration


ApiClient = TypeVar("ApiClient", bound=Apiable)
