from __future__ import annotations

import abc
from typing import Generic, TypeVar


_R = TypeVar("_R")


class Session(abc.ABC, Generic[_R]):
    """Interface that defines a session object that must provide an API session
    functionality.

    Use this interface to type values that might use different types of sessions, or
    would be mocked with a different implementation of a session like requests or httpx.

    Attributes:
        - headers
        - verify

    Methods:
        - post()
        - get()
        - delete()
        - patch()
        - put()
    """
    headers: dict
    verify: bool

    @abc.abstractmethod
    def post(self, url: str, *args, **kwargs) -> _R:
        pass

    @abc.abstractmethod
    def get(self, url: str, *args, **kwargs) -> _R:
        pass

    @abc.abstractmethod
    def delete(self, url: str, *args, **kwargs) -> _R:
        pass

    @abc.abstractmethod
    def patch(self, url: str, *args, **kwargs) -> _R:
        pass

    @abc.abstractmethod
    def put(self, url: str, *args, **kwargs) -> _R:
        pass

    @abc.abstractmethod
    def request(self, method: str, url: str, *args, **kwargs) -> _R:
        pass


AuthenticatedSession = TypeVar("AuthenticatedSession", bound=Session)
