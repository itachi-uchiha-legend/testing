from __future__ import annotations

import abc
from typing import Generic, TypeVar

from .session import AuthenticatedSession
from ..utils import CreateSession
from ...types import AuthParams


class Authable(abc.ABC, Generic[AuthParams]):
    """Interface for classes that manage authentication with external services."""

    def __init__(self) -> None:
        self.session: AuthenticatedSession = CreateSession.create_session()

    @abc.abstractmethod
    def authenticate_session(self, params: AuthParams) -> None:
        """Authenticate the `self.session` attribute of the class using `params`.

        This will let the user create an object using some session, and with this method
        they can authenticate with the service this session will request

        Args:
            params:
                Authentication parameters. Can be an object, dataclass, TypedDict,
                namedtuple or anything that holds all the authentication parameters.
        """


Authenticator = TypeVar("Authenticator", bound=Authable)
